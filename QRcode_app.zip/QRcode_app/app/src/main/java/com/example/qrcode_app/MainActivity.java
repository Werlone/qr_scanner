package com.example.qrcode_app;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etAddress;
    private Button buttonScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Initialize UI components
        etName = findViewById(R.id.etName);
        etAddress = findViewById(R.id.etAddress);
        buttonScan = findViewById(R.id.buttonScan);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set up the Scan button listener
        buttonScan.setOnClickListener(view -> startQRScanner());

        // Set up a click listener on the address EditText to open the website in the browser
        etAddress.setOnClickListener(view -> openAddressInBrowser());
    }

    // Start the QR scanner
    private void startQRScanner() {
        new IntentIntegrator(this)
                .setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                .setPrompt("Scan a QR code")
                .setCameraId(0) // Use back camera
                .setBeepEnabled(false)
                .setBarcodeImageEnabled(false)
                .initiateScan(); // Start scanning
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Handle the result from the scanner
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null && result.getContents() != null) {
            try {
                // Parse the JSON string from the QR code
                JSONObject scannedData = new JSONObject(result.getContents());
                String name = scannedData.optString("title");
                String address = scannedData.optString("website");

                // Update EditText fields with parsed data
                etName.setText(name);
                etAddress.setText(address);

            } catch (Exception e) {
                Toast.makeText(this, "Invalid QR Code", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No QR code scanned", Toast.LENGTH_SHORT).show();
        }
    }

    // Open the URL from the address EditText in a browser
    private void openAddressInBrowser() {
        String url = etAddress.getText().toString().trim();

        if (!url.isEmpty()) {
            // Make sure the URL is valid by checking if it starts with "http" or "https"
            if (!url.startsWith("http://") && !url.startsWith("https://")) {
                url = "http://" + url; // Add "http://" if not present
            }

            // Create an implicit intent to open the browser
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(intent); // Open the URL in the browser
        } else {
            Toast.makeText(this, "No URL to open", Toast.LENGTH_SHORT).show();
        }
    }
}
